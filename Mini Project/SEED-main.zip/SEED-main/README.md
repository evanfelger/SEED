The purpose of this repository is to share the code our team developed amongst ourselves in order to complete the Mini Project Demonstration for EENG350. 
